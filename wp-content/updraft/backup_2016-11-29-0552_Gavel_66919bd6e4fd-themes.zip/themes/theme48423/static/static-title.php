<?php /* Static Name: Title */ ?>
<div class="title-wrap">
	<?php get_template_part('title'); ?>
</div>