<?php
	cherry_related_posts(array('height_thumbnail' => 200));
?>